<form class="form-horizontal form-label-left" method="post" action="test.php" enctype="multipart/form-data" onKeyDown="if (event.keyCode == 13) {return false;}">
  <input type="file" name="file1" id="file1"/>
  <button type="submit" class="btn btn-success">送出</button>
</form>
