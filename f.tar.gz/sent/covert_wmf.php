<?php
echo 'Current PHP version: ' . phpversion();
$im = new Imagick( 'test.jpg' );
/*
$filename = "upload/Q32A1.wmf";

$image = new Imagick();

$image->setresolution(300, 300);

$image->readimage($filename);

$image->resizeImage(1500,0,Imagick::FILTER_LANCZOS,1);

$image->setImageFormat('jpg');

$image->writeImage("2.jpg");
*/
?>
